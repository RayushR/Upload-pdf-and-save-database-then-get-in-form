<?php

// include('class.pdf2text.php');

// // $pdfText = ''; 
// // if(isset($_POST['submit'])){ 
// //     // If file is selected 
// //     if(!empty($_FILES["pdf_file"]["name"])){ 
// //         // File upload path 
// //         $fileName = basename($_FILES["pdf_file"]["name"]); 
// //         $fileType = pathinfo($fileName, PATHINFO_EXTENSION); 
//         $a = new PDF2Text();
//         $a->setFilename('1.pdf');
//         $a->decodePDF();
//         $data = $a->output();
//         echo $data;
        // echo $a;
//     }
// }

?>



<?php
    // include ( 'vendor/autoload.php' ) ;
    //     $pdfText = ''; 

    //     $file =  $_FILES['file']['tmp_name'] ;

    //     $server_file = $file;
        
    //     $parser = new \Smalot\PdfParser\Parser();
    //     $pdf = $parser->parseFile($server_file);
    //     if ($pdf != "") {
    //         $original_text = $pdf->getText();
    //         if ($original_text != "") {
    //             $text = nl2br($original_text); // Paragraphs and line break formatting
    //             $text = clean_ascii_characters($text); // Check special characters
    //             $text = str_replace(array("<br /> <br /> <br />", "<br> <br> <br>"), "<br /> <br />", $text); // Optional
    //             $text = addslashes($text); // Backslashes for single quotes     
    //             $text = stripslashes($text);
    //             $text = strip_tags($text);
                
    //             $check_text = preg_split('/\s+/', $text, -1, PREG_SPLIT_NO_EMPTY);
                
    //             $no_spacing_error = 0;
    //             $excessive_spacing_error = 0;
    //             foreach($check_text as $word_key => $word) {
    //                 if (strlen($word) >= 30) { // 30 is a limit that I set for a word length, assuming that no word would be 30 length long
    //                     $no_spacing_error++;
    //                 } else if (strlen($word) == 1) { // To check if the word is 1 word length
    //                     if (preg_match('/^[A-Za-z]+$/', $word)) { // Only consider alphabetical words and ignore numbers.
    //                         $excessive_spacing_error++;
    //                     }
    //                 }
    //             }
                
    //             // Set the boundaries of errors you can accept
    //             // E.g., we reject the change if there are 30 or more $no_spacing_error or 150 or more $excessive_spacing_error issues
    //             if ($no_spacing_error >= 30 || $excessive_spacing_error >= 150) {
    //                 echo "Too many formatting issues<br />";
    //                 echo $text;
    //             } else {
    //                 // echo "Success!<br />";
    //                 echo $text;
    //             }
    //             /* End of additional step */
    //             /**************************/
                
    //         } else {
    //             echo "No text extracted from PDF.";
    //         }
    //     } else {
    //         echo "parseFile fns failed. Not a PDF.";
    //     }
 
    //     // Common function
    //     function clean_ascii_characters($string) {
    //     $string = str_replace(array('-', '–'), '-', $string);
    //     $string = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $string);  
    //     return $string;
    //     }

    include('vendor/autoload.php');
    
    // Function to clean ASCII characters (as you provided)
    function clean_ascii_characters($string) {
        $string = str_replace(array('-', '–'), '-', $string);
        $string = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $string);  
        return $string;
    }
    
    // Check if a file was uploaded successfully
    if ($_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['file']['tmp_name'];
    
        // Parse the PDF file
        $parser = new \Smalot\PdfParser\Parser();
        $pdf = $parser->parseFile($file);
    
        if ($pdf !== false) { // Check if parsing was successful
            $original_text = $pdf->getText();
            if ($original_text != "") {
                // Your text processing here ...
                $policyNumber = isset($matches[1]) ? trim($matches[1]) : '';
                $insuredName = isset($matches[1]) ? trim($matches[1]) : '';
                $Address = isset($matches[1]) ? trim($matches[1]) : '';
    
                $matches = [];
    
                // Extract relevant details using regular expressions
                preg_match('/Policy Number\s*:\s*([^\n]+)/', $original_text, $matches);
                $policyNumber = isset($matches[1]) ? trim($matches[1]) : '';

                preg_match('/Insured Name\s*:\s*([^\n]+)/', $original_text, $matches);
                $insuredName = isset($matches[1]) ? trim($matches[1]) : '';

                preg_match('/Address\s*:\s*([^\n]+)/', $original_text, $matches);
                $Address = isset($matches[1]) ? trim($matches[1]) : '';
    
                // ... Extract other relevant details ...
    
                // Create a PDO connection to your database
                $db_host = 'localhost';
                $db_name = 'pdf_ex';
                $db_user = 'root';
                $db_password = '';
    
                try {
                    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name", $db_user, $db_password);
                    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
                    // Insert the processed text into the database
                    $insertQuery = "INSERT INTO tbl_data (policy_number, insured_name, address) VALUES (:policy_number, :insured_name, :address)";
                    $stmt = $pdo->prepare($insertQuery);
                    $stmt->bindParam(':policy_number', $policyNumber, PDO::PARAM_STR);
                    $stmt->bindParam(':insured_name', $insuredName, PDO::PARAM_STR); // Assuming you have $insuredName available
                    $stmt->bindParam(':address', $Address, PDO::PARAM_STR); // Assuming you have $insuredName available
                    $stmt->execute();
    
                    echo "Text saved to the database.";
                } catch (PDOException $e) {
                    echo "Database connection failed: " . $e->getMessage();
                }
            } else {
                echo "No text extracted from PDF.";
            }
        } else {
            echo "parseFile function failed. Not a PDF.";
        }
    } else {
        echo "File upload error.";
    }
?>